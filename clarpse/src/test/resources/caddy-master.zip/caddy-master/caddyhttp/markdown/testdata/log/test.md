---
title: Markdown test 2
sitename: A Caddy website
---

## Welcome on the blog

Body

``` go
func getTrue() bool {
    return true
}
```
