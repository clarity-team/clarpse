# Broker

The Istio Service Broker provides an implementation of the [Open Service Broker API](https://github.com/openservicebrokerapi/servicebroker) for Istio.
This API enables external service consumers to automatically provision and access Istio services. 

The broker is currently under early development.
