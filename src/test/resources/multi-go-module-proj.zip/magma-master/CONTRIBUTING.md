# Contributing to Magma
We want to make contributing to this project as easy and transparent as
possible.

Please refer to the [Governance](https://github.com/magma/community)
and [Contribution](https://github.com/magma/community/blob/main/CONTRIBUTING.md)
model to get started.

The [Wiki](https://github.com/magma/magma/wiki) outlines
language specific guidelines.
