package download

const ServiceName = "DOWNLOAD"
