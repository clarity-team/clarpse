package fbinternal

const (
	ModuleName                = "fbinternal"
	TestControllerNetworkType = "testcontroller"
)
