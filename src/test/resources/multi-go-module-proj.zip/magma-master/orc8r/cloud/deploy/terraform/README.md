# Orchestrator Terraform

Content has been moved to
https://magma.github.io/magma/docs/next/orc8r/deploy_install.

The old root module which used to be in this directory has been deprecated.
Check the upgrade steps in the link above to upgrade to the new deployment
model.
